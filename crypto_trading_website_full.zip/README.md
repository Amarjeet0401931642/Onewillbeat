# Crypto Trading Website

This is the full version of the trading strategy platform.